from django.contrib import admin
from .models import Event, Venue, Organizer, Attendance

# Register your models here.
@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title','date','venue','organizer')

    search_fields = ('title','venue','organizer')
    ordering = ('title',)
    list_filter = ('date','venue')

    fieldsets = (
        ('Required Information', {
            'description':"These fields are required",
            'fields':('title','date','venue')
        }),
        ('Optional Information', {
            'classes': ('collapse',),
            'fields':('description','max_capacity')
        })
    )



admin.site.register(Venue)
admin.site.register(Organizer)
admin.site.register(Attendance)
