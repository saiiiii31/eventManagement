from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout, name='logout'),
    path('toDo/', views.toDo, name='toDo'),
    path('event-single/<int:event_id>/', views.event_detail, name='event_detail'),
    path('attend-event/<int:event_id>/', views.attend_event, name='attend_event'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)