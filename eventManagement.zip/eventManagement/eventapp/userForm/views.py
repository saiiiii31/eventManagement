from django.shortcuts import render,redirect, get_object_or_404
from .models import Event, Attendance
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required

# Create your views here.
def index(request):
    events = Event.objects.all()
    return render(request, 'index.html', {'events': events})



def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            request.session['user_id'] = user.id
            messages.success(request, "Login successfull")
            return redirect('/toDo/')
        else:
            # Authentication failed, display error message
            messages.error(request, "Invalid username or password. Please try again.")
            return render(request, 'login.html')

    return render(request, 'login.html')

def register(request):
    if request.method == "POST":
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = User.objects.create_user(username= username, email = email, password = password)
        user.first_name = fname
        user.last_name = lname
        user.save()
        messages.success(request, "Registered successfully")

    return render(request, 'register.html')


def logout(request):
    auth_logout(request)
    return redirect('/')



@login_required
def toDo(request):
    events = Event.objects.all()
    attended_events = Attendance.objects.filter(user=request.user).select_related('event')
    return render(request, 'toDo.html', {'events': events , 'attended_events' : attended_events})

def event_detail(request, event_id):
    event = get_object_or_404(Event, pk=event_id)
    return render(request, 'event_single.html', {'event': event})

@login_required
def attend_event(request, event_id):
    event = get_object_or_404(Event, pk=event_id)
    Attendance.objects.create(event=event, user=request.user)
    return redirect('event_detail', event_id=event_id)